using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PluginInterface;

namespace MarketWatch
{
    public class Program : IPlugin
    {

        public string getInformation()
        {
            return "HIII";
        }

        public string getPluginName()
        {
            return "Hello Kiran";
        }
       /* public static void Main(String[] arg)
        {
            
        }*/
    }
}
