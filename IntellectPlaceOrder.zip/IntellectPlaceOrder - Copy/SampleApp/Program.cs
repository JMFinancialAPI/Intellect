﻿using BackTestUtilityApplication;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TraderArc
{
    class Program
    {
      
        [STAThread]
        static void Main(string[] args)
        {
            
            Thread t = new Thread(() => StartTCPCommunication());
            t.SetApartmentState(ApartmentState.STA);
            t.Start();


            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //  Application.Run(new MyForm());
            // Application.Run(new MyForm());
            //Application.Run(new Login());

        }

        private static void StartTCPCommunication()
        {

            Application.EnableVisualStyles();
            //Application.Run(new RichUI());
            Application.Run(new Login());

            //   Application.Run(new MainWindow(OAuthToken));
        }
    }
}
