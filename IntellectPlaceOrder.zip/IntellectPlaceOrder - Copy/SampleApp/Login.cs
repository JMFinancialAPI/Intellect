﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackTestUtilityApplication
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var client = new RestClient("https://myconnect.jmfonline.in/trading/v1/Login");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
         
            request.AddHeader("apikey", "6ml54F2u1ZJOHgdxNitN1GojKkP6m5vAIpEvyHtdGE14R7lZ");
            request.AddHeader("Content-Type", "application/json");
            var body = @"{
 " + "\n" +
            @"    ""LoginID"": ""156319209"",
 " + "\n" +
            @"    ""Password"": ""Rama@123"",
 " + "\n" +
            @"    ""Dob"": ""10031980"",
 " + "\n" +
            @"    ""Pan"": ""AHHPG6270A""
 " + "\n" +
            @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            dynamic respNEW = JObject.Parse(response.Content);
            dynamic tokendataNEW = respNEW.data;
            dynamic authToken = tokendataNEW.jwtToken;
            String ActualToken = authToken.Value;
            //MessageBox.Show(ActualToken);

                client = new RestClient("https://myconnect.jmfonline.in/trading/v1/PlaceOrder");
                client.Timeout = -1;
                request = new RestRequest(Method.POST);
                request.AddHeader("apikey", "6ml54F2u1ZJOHgdxNitN1GojKkP6m5vAIpEvyHtdGE14R7lZ");
                request.AddHeader("Authorization", "Bearer " + ActualToken);
                request.AddHeader("Content-Type", "application/json");
                body = @"{
" + "\n" +
                @"    ""variety"": ""NORMAL"",
" + "\n" +
                @"    ""tradingsymbol"": ""ACC-EQ"",
" + "\n" +
                @"    ""symboltoken"": ""22"",
" + "\n" +
                @"    ""transactiontype"": ""BUY"",
" + "\n" +
                @"    ""exchange"": ""NSE"",
" + "\n" +
                @"    ""ordertype"": ""MARKET"",
" + "\n" +
                @"    ""producttype"": ""INTRADAY"",
" + "\n" +
                @"    ""duration"": ""DAY"",
" + "\n" +
                @"    ""price"": ""0"",
" + "\n" +
                @"    ""squareoff"": ""0"",
" + "\n" +
                @"    ""stoploss"": ""0"",
" + "\n" +
                @"    ""quantity"": ""20"",
" + "\n" +
                @"    ""disclosedquantity"": ""0"",
" + "\n" +
                @"    ""triggerprice"": ""0""
" + "\n" +
                @"}";
                request.AddParameter("application/json", body, ParameterType.RequestBody);
                response = client.Execute(request);

                respNEW = JObject.Parse(response.Content);
                //tokendataNEW = respNEW.data;
                String Intellectresponse = respNEW.ToString();
                dgb.Rows.Add(Intellectresponse);
               
           
        }
    }
}
