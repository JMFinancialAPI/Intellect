﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System.Windows.Forms;

namespace TraderArc
{
    internal class JM_UI : Form
    {
        private Button btnLogin;

        private void InitializeComponent()
        {
            this.btnLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(37, 36);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(80, 29);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "LOGIN";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // JM_UI
            // 
            this.ClientSize = new System.Drawing.Size(453, 217);
            this.Controls.Add(this.btnLogin);
            this.Name = "JM_UI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "JM Financial";
            this.ResumeLayout(false);

        }

        private void btnLogin_Click(object sender, System.EventArgs e)
        {

        }

        /* private void btnLogin_Click(object sender, System.EventArgs e)
         {
             var client = new RestClient("https://myconnect.jmfonline.in/trading/v1/Login");
             client.Timeout = -1;
             var request = new RestRequest(Method.POST);
             request.AddHeader("apikey", "E9ROIfZOlJXKm4ZGUl9xJDHGCEjgNQDa");
             request.AddHeader("Content-Type", "application/json");
             var body = @"{
 " + "\n" +
             @"    ""LoginID"": ""156300247"",
 " + "\n" +
             @"    ""Password"": ""tcs@111"",
 " + "\n" +
             @"    ""Dob"": ""09101983"",
 " + "\n" +
             @"    ""Pan"": """"
 " + "\n" +
             @"}";
             request.AddParameter("application/json", body, ParameterType.RequestBody);
             IRestResponse response = client.Execute(request);
             dynamic respNEW = JObject.Parse(response.Content);
             dynamic tokendataNEW = respNEW.data;
             dynamic authToken = tokendataNEW.jwtToken;
             MessageBox.Show(authToken);
             // Console.WriteLine(response.Content);
         }*/
    }
}